import boto3
import json
import csv
import datetime
import os


def handler(event, context):
    print(event)
    
    # use this endpoint for localstack
    endpoint_url = "http://localhost.localstack.cloud:4566"
    sqs = boto3.client('sqs', endpoint_url=endpoint_url)
    list_queues_resp = sqs.list_queues()
    queue_url = list_queues_resp['QueueUrls'][0]

    output = []

    # while len(output) < 20:
    #     msg = sqs.receive_message(
    #         QueueUrl=queue_url,
    #         MaxNumberOfMessages=1
    #     )
    #     output.append(json.loads(msg['Messages'][0]['Body']))
        
    #     # delete received message
    #     receipt_handle = msg['Messages'][0]['ReceiptHandle']
    #     delete_message_resp = sqs.delete_message(
    #         QueueUrl=queue_url,
    #         ReceiptHandle=receipt_handle,
    #     )
        
    filename = 'app_output-{date:%Y-%m-%d_%H:%M:%S}.txt'.format(date=datetime.datetime.now())
    with open(filename, 'w') as f:
        
        # using csv.writer method from CSV package
        write = csv.writer(f)
        
        write.writerows(event)
        
    s3 = boto3.client("s3", endpoint_url=endpoint_url)
    # put object to the app bucket
    put_object_resp = s3.put_object(
        Body=filename,
        Bucket='app-bucket',
        Key=filename,
    )

    os.remove(filename)